# Animated Login and Register Form.

This is my study to make a working login and register page with some animation.

## Screenshot

![image.png](./preview.png)
